
import CustomFieldsApp from './components/CustomFieldsApp';

function App() {
  return (
    <div className="App">
      <CustomFieldsApp />
    </div>
  );
}

export default App;
